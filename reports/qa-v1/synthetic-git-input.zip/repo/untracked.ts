export const independentUntracked = 7;
